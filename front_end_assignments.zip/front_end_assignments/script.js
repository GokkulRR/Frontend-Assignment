function my(){
    document.getElementById('click').innerHTML = 'Joined as Intern in KL'
}