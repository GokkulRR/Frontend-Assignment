let total_price = 0;
let itemPrices = [];
var amountofProducts = 0;

function addToCart(itemName, price, path) {
  let side_Cart = document.getElementById("side_cart");
  side_Cart.innerHTML += `<h6><img src=${path} style="width: 15px; height: 15px;">${itemName}<button class="remove-button cross-button" style="font-size:20px; padding: 0px 0px;">&#215;</button></h6>`;

  let itemPrice = parseInt(price);
  itemPrices.push(itemPrice);
  total_price += itemPrice;
  console.log(itemPrices)

  let tp = document.getElementById("priceT");
  tp.innerHTML = `<h4>Total amount: ${total_price}</h4>`;

  let removeButtons = document.getElementsByClassName("remove-button");
  for (let i = 0; i < removeButtons.length; i++) {
    removeButtons[i].addEventListener("click", function () {
      let itemContainer = this.parentNode;
      let index = Array.prototype.indexOf.call(itemContainer.parentNode.children, itemContainer);
      itemContainer.remove();
      total_price -= itemPrices[index];
      itemPrices.splice(index, 1);
      let x = Math.round(total_price);
      tp.innerHTML = `<h4>Total amount: ${x}</h4>`;
      return x;
    });
  }
}


function gotopayments() {
  if (document.getElementById("side_cart").innerHTML.trim() === "") {
    // document.getElementById("side_cart").innerHTML = "Please select an item";
    alert("Cart is empty.")
  }
  else {
    window.open("checkout.html", "_blank");
  }
}



